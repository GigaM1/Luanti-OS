local frame = 1
local animation_count = 0
minetest.register_on_joinplayer(function(player)
    apagado(player)
    cielo(player)
    local name = player:get_player_name()
    pantalla_carga(player)
    local function animate()
        if animation_count < 8 then 
            pantalla_carga(player)
            animation_count = animation_count + 1
            minetest.after(0.5, animate) 
            else
            minetest.close_formspec(name, "carga:loading")
        end
    end
    animate()
end)

function apagado(player)
    player:hud_set_flags({
        hotbar =        false,
        healthbar =     false,
        crosshair =     false,
        wielditem =     false,
        breathbar =     false,
        minimap =       false,
        minimap_radar = false,
    })
end
function cielo(player)
    player:set_sky({
        base_color = "#000000",
        type = "plain",
        clouds = false,
    })
    player:set_stars({visible = false})
    player:set_sun({visible = false, sunrise_visible = false})
    player:set_moon({visible = false})
    player:override_day_night_ratio(0)
end
local frames = {
    "carga_frame1.png",
    "carga_frame2.png",
    "carga_frame3.png",
    "carga_frame4.png",
    "carga_frame5.png",
    "carga_frame6.png",
    "carga_frame7.png",
    "carga_frame8.png"
}
function pantalla_carga(player)
local name = player:get_player_name()

    minetest.show_formspec(name, "carga:loading", 
        "size[8,8]" ..
        "image[2,2;4,4;" .. frames[frame] .. "]" ..
        "label[1.8,6;Cargando, por favor espera...]" ..
        "bgcolor[#000000]"
    )
    frame = frame + 1
    if frame > #frames then
        frame = 1
    end
end
