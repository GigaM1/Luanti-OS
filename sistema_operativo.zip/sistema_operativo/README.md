# English: Luanti OS is a "Game" that simulates a functional operating system

The system works with the management of forsmpec simulating the traditional tasks of a PC

Luanti os is a personal project that I decided to show to the community

Changes are expected if necessary since it is not 100% finished.

The system currently counts 10/15/24

with a calculator with basic operations, logarithms, exponents and trigonometric functions

an option to display desktop content

and a system for creating real-time files that can be added directly to the system file directory and built itself

Note: It is necessary to disable mod protection since mods create and delete files in their root directories: Minetestgame/Games/operating_system


to make a new lua create it from the files and add its dofile to init.lua

Español: Luanti OS es un "Juego" que simula un sistema operativo funcional

el sistema trabaja con el manejo de forsmpec simulando las tareas tradicionales de una pc

Luanti os es un proyecto personal que decidi mostrar a la comunidad

se esperan cambios de ser necesarios ya que no esta 100 % terminado

El sistema cuenta actualmente 15/10/24

con una calculadora con operaciones basicas,logaritmos,exponentes y funciones trigonometricas

una opcion para mostrar el contenido del escritorio

y un sistema para creacion de archivos en tiempo real que se pueden agregar directamente al directorio de archivos

del sistema y construirse a si mismo

Nota:Es necesario desactivar la proteccion de mods ya que el os crea y elimina archivos en su directorios raiz: Minetestgame/Games/sistema_operativo

para hacer un nuevo lua crealo desde los archivos y añade su dofile a init.lua




freesound Creative Commons 0 :
The person who associated a work with this deed has dedicated the work to the public domain by waiving all of his or her rights to the work worldwide under copyright law, including all related and neighboring rights, to the extent allowed by law.
You can copy, modify, distribute and perform the work, even for commercial purposes, all without asking permission. See Other Information below.
Other Information
In no way are the patent or trademark rights of any person affected by CC0, nor are the rights that other persons may have in the work or in how the work is used, such as publicity or privacy rights.
Unless expressly stated otherwise, the person who associated a work with this deed makes no warranties about the work, and disclaims liability for all uses of the work, to the fullest extent permitted by applicable law.
When using or citing the work, you should not imply endorsement by the author or the affirmer.
 Notice
The Commons Deed is not a legal instrument. It is simply a handy reference for understanding the CC0 Legal Code, a human-readable expression of some of its key terms. Think of it as the user-friendly interface to the CC0 Legal Code beneath. This Deed itself has no legal value, and its contents do not appear in CC0.

Creative Commons is not a law firm and does not provide legal services. Distributing, displaying, or linking to this Commons Deed does not create an attorney-client relationship.

Creative Commons has not verified the copyright status of any work to which CC0 has been applied. CC makes no warranties about any work or its copyright status in any jurisdiction, and disclaims all liability for all uses of any work.

Creative Commons is the nonprofit behind the open licenses and other legal tools that allow creators to share their work. Our legal tools are free to use.

start sound : https://freesound.org/people/bingopro/sounds/614431/